function runDSTv6
%------------------------------------------------------------------------
%   This code (nov 2016) is a simple extension of previous version.
%   The differences are:
%       - it loads a different globalParameters file 
%       - it drives the code from a different path
%       - it loads the path on top so that no other version installed would
%       interfere with it
%       - it saves the data in a dataFiles folder
%       - setup for a 100cm distance
%       - all flip are now flip2 to avoid matlab conflicts
%       - it saves a diary files with the command window
%------------------------------------------------------------------------%------------------------------------------------------------------------

%------------------------------------------------------------------------
% A wrapper function to launch all parts of DST v4, providing the correct parameters
% It is part of :
% STaM Project [Stereo-Training and MRI]
% Aug 2014 - Berkeley
% Modified oct 2016 to work with DSTv5
%=======================================================================

       clc
       param.Box=20; 
       param.inputMode=1;
       param.quickMode=2;
       param.displayMode=2;
       param.polarity = 4;
              
       DSTv6(param);
 
